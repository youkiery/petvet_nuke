<?php

/**
 * @Project NUKEVIET 3.1
 * @Author PCD GROUP (dinhpc.it@gmail.com)
 * @Copyright (C) 2011 PCD GROUP. All rights reserved
 * @Createdate Mon, 23 May 2011 05:30:42 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$module_version = array( //
		"name" => "Articles", //
		"modfuncs" => "main,detail", //
		"submenu" => "main,detail", //
		"is_sysmod" => 0, //
		"virtual" => 1, //
		"version" => "3.1.0", //
		"date" => "Mon, 23 May 2011 05:30:43 GMT", //
		"author" => "VINADES (contact@vinades.vn)", //
		"uploads_dir" => array($module_name), //
		"files_dir" => array( $module_name ),
		"note" => "" //
	);

?>