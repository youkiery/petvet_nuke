<?php
/**
 * @Project NUKEVIET 3.0
 * @Author VINADES., JSC (contact@vinades.vn)
 * @Copyright (C) 2011 VINADES ., JSC. All rights reserved
 * @Createdate Jan 17, 2011  11:34:27 AM
 */

if (!defined('NV_MAINFILE'))
	die('Stop!!!');

if (!nv_function_exists('nv_menu_theme_360buy')) {

	function nv_menu_theme_360buy($block_config) {
		global $home, $db, $db_config, $global_config, $site_mods, $module_info, $module_name, $module_file, $module_data, $lang_global, $catid;

		if ($home != 1) {
			if (file_exists(NV_ROOTDIR . "/themes/" . $global_config['site_theme'] . "/modules/menu/menu_theme_360buy.tpl")) {
				$block_theme = $global_config['site_theme'];
			} else {
				$block_theme = "default";
			}
			$xtpl = new XTemplate("menu_theme_360buy.tpl", NV_ROOTDIR . "/themes/" . $block_theme . "/modules/menu");

		} else {
			if (file_exists(NV_ROOTDIR . "/themes/" . $global_config['site_theme'] . "/modules/menu/menu_theme_360buy_index.tpl")) {
				$block_theme = $global_config['site_theme'];
			} else {
				$block_theme = "default";
			}
			$xtpl = new XTemplate("menu_theme_360buy_index.tpl", NV_ROOTDIR . "/themes/" . $block_theme . "/modules/menu");
		}

		$xtpl -> assign('LANG', $lang_global);
		$xtpl -> assign('NV_BASE_SITEURL', NV_BASE_SITEURL);
		$xtpl -> assign('BLOCK_THEME', $block_theme);
		$xtpl -> assign('THEME_SITE_HREF', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA);
		$xtpl -> assign('THEME_DIGCLOCK_TEXT', nv_date("l:  H:i - d/m/Y", NV_CURRENTTIME));
		$xtpl -> assign('THEME_RSS_INDEX_HREF', NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=rss");

		$arr_home['index'] = array("custom_title" => $lang_global['Home'], "in_menu" => 0);
		$site_mods2 = array_merge($arr_home, $site_mods);
		$a = 0;
		foreach ($site_mods2 as $modname => $modvalues) {
			if (!empty($modvalues['in_menu'])) {
				if ($home == 1 && $a == 0) {
					$module_current = 'class="active"';
				} elseif ($modname == $module_name and $home != 1) {
					$module_current = 'class="active"';
				} else {
					$module_current = '';
				}
				if ($modname == "index") {
					$link = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA;
				} else {
					$link = NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $modname;
				}
				$aryay_menu = array("module_file" => $module_file, "title" => $modvalues['custom_title'], "class" => $modname, "current" => $module_current, "link" => $link);
				if (!empty($modvalues['funcs'])) {
					$sub_nav_item = array();

					if ($modvalues['module_file'] == "news" or $modvalues['module_file'] == "weblinks") {
						$result2 = "SELECT `title`, `alias` FROM `" . NV_PREFIXLANG . "_" . $modvalues['module_data'] . "_cat` WHERE `parentid`='0' AND `inhome`='1' ORDER BY `weight` ASC LIMIT 0,10";
						$list = nv_db_cache($result2, '', $modname);
						foreach ($list as $l) {
							$sub_nav_item[] = array('title' => $l['title'], 'link' => NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $modname . "&amp;" . NV_OP_VARIABLE . "=" . $l['alias']);
						}
					}
					if ($modvalues['module_file'] == "shops") {
						$result2 = "SELECT " . NV_LANG_DATA . "_title as title, " . NV_LANG_DATA . "_alias as alias FROM `" . $db_config['prefix'] . "_" . $modvalues['module_data'] . "_catalogs` WHERE `parentid`='0' AND `inhome`='1' ORDER BY `weight` ASC LIMIT 0,10";
						$list = nv_db_cache($result2, '', $modname);
						foreach ($list as $l) {
							$sub_nav_item[] = array('title' => $l['title'], 'link' => NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $modname . "&amp;" . NV_OP_VARIABLE . "=" . $l['alias']);
						}
					} elseif ($modvalues['module_file'] == "download") {
						$result2 = "SELECT `title`, `alias` FROM `" . NV_PREFIXLANG . "_" . $modvalues['module_data'] . "_categories` WHERE `parentid`='0' AND `status`='1'ORDER BY `weight` ASC LIMIT 0,10";
						$list = nv_db_cache($result2, '', $modname);
						foreach ($list as $l) {
							$sub_nav_item[] = array('title' => $l['title'], 'link' => NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $modname . "&amp;" . NV_OP_VARIABLE . "=" . $l['alias']);
						}
					} elseif ($modname == "users") {
						if (defined('NV_IS_USER')) {
							$in_submenu_users = array("changepass", "openid", "logout");
						} else {
							$in_submenu_users = array("login", "register", "lostpass");
						}
						foreach ($modvalues['funcs'] as $key => $sub_item) {
							if ($sub_item['in_submenu'] == 1 and in_array($key, $in_submenu_users)) {
								$sub_nav_item[] = array("title" => $sub_item['func_custom_name'], "link" => NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $modname . "&amp;" . NV_OP_VARIABLE . "=" . $key);
							}
						}
					} else {
						foreach ($modvalues['funcs'] as $key => $sub_item) {
							if ($sub_item['in_submenu'] == 1) {
								$sub_nav_item[] = array("title" => $sub_item['func_custom_name'], "link" => NV_BASE_SITEURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&amp;" . NV_NAME_VARIABLE . "=" . $modname . "&amp;" . NV_OP_VARIABLE . "=" . $key);
							}
						}
					}
					if (!empty($sub_nav_item)) {
						foreach ($sub_nav_item as $sub_nav) {
							$xtpl -> assign('SUB', $sub_nav);
							$xtpl -> parse('main.top_menu.sub.item');
						}
						$xtpl -> parse('main.top_menu.sub');
					}
				}
				$xtpl -> assign('TOP_MENU', $aryay_menu);
				$xtpl -> parse('main.top_menu');
			}
			$a++;
		}

		$xtpl -> parse('main.news_cat');
		$xtpl -> parse('main');
		return $xtpl -> text('main');
	}

}

if (defined('NV_SYSTEM')) {
	$content = nv_menu_theme_360buy($block_config);
}
?>