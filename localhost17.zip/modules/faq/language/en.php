<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language English
* @Createdate Jul 06, 2011, 04:38:01 PM
*/

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="";
$lang_translator['createdate'] ="";
$lang_translator['copyright'] ="";
$lang_translator['info'] ="";
$lang_translator['langtype'] ="lang_module";

$lang_module['faq_welcome'] = "Frequently Asked Questions";
$lang_module['go_top'] = "Top";
$lang_module['faq_question'] = "Question";
$lang_module['faq_answer'] = "Answer";

?>