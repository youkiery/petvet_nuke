<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language Türkçe
* @Createdate Jul 06, 2011, 04:38:03 PM
*/

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="Nukevietdestek.com (destek@nukevietdestek.com)";
$lang_translator['createdate'] ="14/06/2011/03:30";
$lang_translator['copyright'] ="@Copyright (C) 2011 Nukevietdestek.com tüm hakları saklıdır";
$lang_translator['info'] ="Dil Sevimsiz tarafından tercüme edildi";
$lang_translator['langtype'] ="lang_module";

$lang_module['add_time'] = "Oluşturma";
$lang_module['edit_time'] = "Son ek";
$lang_module['not_found'] = "Üzgünüz! Kategoriler yok";

?>