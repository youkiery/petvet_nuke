<?php

/**
* @Project NUKEVIET-MUSIC
* @Author Phan Tan Dung (phantandung92@gmail.com)
* @copyright 2011
* @createdate 05/12/2010 09:47
*/

if ( ! defined( 'NV_ADMIN' ) or ! defined( 'NV_MAINFILE' )) die( 'Stop!!!' );

$module_version = array( 
	"name" => "vac", // Tieu de module
	"modfuncs" => "main",
	"is_sysmod" => 0,
	"virtual" => 1,
	"version" => "3.0.01",
	"date" => "Wed, 26 Jan 2011 12:47:15 GMT",
	"author" => "PHAN TAN DUNG (email: phantandung1912@gmail.com)",
	"note"=>"",
	"uploads_dir" => array(
		$module_name
	)
);
?>