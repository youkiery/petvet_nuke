<?php

/**
 * @Project NUKEVIET 3.0
 * @Author VINADES (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES. All rights reserved
 * @Createdate Apr 20, 2010 10:47:41 AM
 */

if ( ! defined( 'NV_IS_MOD_HOME' ) ) die( 'Stop!!!' );

include ( NV_ROOTDIR . "/includes/header.php" );
echo nv_site_theme( '' );
include ( NV_ROOTDIR . "/includes/footer.php" );

?>