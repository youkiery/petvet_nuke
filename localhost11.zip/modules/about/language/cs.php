<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language česky
* @Createdate Jul 06, 2011, 04:38:02 PM
*/

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="http://datviet.cz";
$lang_translator['createdate'] ="01/08/2010, 21:40";
$lang_translator['copyright'] ="@Copyright (C) 2010 VINADES.,JSC.. All rights reserved";
$lang_translator['info'] ="YM: datvietinfo2010 ";
$lang_translator['langtype'] ="lang_module";

$lang_module['add_time'] = "Dodatek času";
$lang_module['edit_time'] = "Poslední uprava";
$lang_module['not_found'] = "Litujeme!Kategorie neexistuje";

?>