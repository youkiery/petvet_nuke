<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language Türkçe
* @Createdate Jul 06, 2011, 04:38:03 PM
*/

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="";
$lang_translator['createdate'] ="";
$lang_translator['copyright'] ="";
$lang_translator['info'] ="Language translated from http://translate.nukeviet.vn";
$lang_translator['langtype'] ="lang_module";

$lang_block['menu'] = "Menüsünü seçin";
$lang_block['is_viewdes'] = "Menüsünde giriş göster";
$lang_block['title_length'] = "Adı karakter sayısı";
$lang_block['type'] = "Menü stili";
$lang_block['m_type1'] = "Supersubs ile";
$lang_block['m_type2'] = "Nav_bar";
$lang_block['m_type3'] = "Dikey";
$lang_block['m_type4'] = "Treeview";
$lang_block['m_type5'] = "Üst Menü Çubuğu";
$lang_block['m_type6'] = "Yan Menü Çubuğu";
$lang_block['m_type7'] = "Pro_dropdown";
$lang_block['m_type8'] = "Dikey 2 katlı";

?>