<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language Tiếng Việt
* @Createdate Jul 06, 2011, 04:38:01 PM
*/

 if (! defined('NV_ADMIN') or ! defined('NV_MAINFILE')){
 die('Stop!!!');
}

$lang_translator['author'] ="VINADES.,JSC (contact@vinades.vn)";
$lang_translator['createdate'] ="15/04/2011, 15:22";
$lang_translator['copyright'] ="@Copyright (C) 2010 VINADES.,JSC. All rights reserved";
$lang_translator['info'] ="";
$lang_translator['langtype'] ="lang_module";

$lang_module['menu_manager'] = "Quản lý menu";
$lang_module['type_menu_manager'] = "Quản lý loại menu";
$lang_module['add_menu'] = "Thêm khối menu";
$lang_module['edit_menu'] = "Sửa menu";
$lang_module['menu_name'] = "Tên menu";
$lang_module['menu_description'] = "Mô tả";
$lang_module['error_menu_name'] = "Lỗi: Bạn chưa nhập tên menu";
$lang_module['menu_number'] = "Số phần tử";
$lang_module['save'] = "Lưu";
$lang_module['edit'] = "Sửa";
$lang_module['delete'] = "Xóa";
$lang_module['errorsave'] = "Lỗi: Hệ thống không ghi được dữ liệu. Có thể tên menu bị trùng. Vui lòng thử tên khác.";
$lang_module['number'] = "Số TT";
$lang_module['type_header'] = "Menu top";
$lang_module['type_along'] = "Menu dọc";
$lang_module['type_footer'] = "Menu botton";
$lang_module['menu'] = "Menu";
$lang_module['type_tree'] = "Menu cây thư mục";
$lang_module['m_list'] = "Danh sách menu";
$lang_module['add_type_menu'] = "Chọn loại Menu";
$lang_module['module_name'] = "Chọn module";
$lang_module['cho_module'] = "Chọn module";
$lang_module['name_blog'] = "Menu";
$lang_module['error_menu_blog'] = "Lỗi: Chưa nhập khối menu";
$lang_module['action'] = "Hoạt động";
$lang_module['data_no'] = "Hệ thống chưa có dữ liệu";
$lang_module['block'] = "Khối menu này có";
$lang_module['block2'] = " Menu, bạn hãy xoá menu trước khi xoá menu này";
$lang_module['back'] = "Trở về mục trước ";
$lang_module['title_exit_cat'] = "Tên này đã tồn tại";
$lang_module['add_item'] = "Thêm mục cho menu";
$lang_module['title'] = "Tên mục";
$lang_module['item_menu'] = "Các mục thuộc module";
$lang_module['chomodule'] = "Liên kết đến module";
$lang_module['select'] = "Chọn";
$lang_module['note'] = "Ghi chú";
$lang_module['link'] = "Đường dẫn liên kết";
$lang_module['module'] = "Module";
$lang_module['op'] = "op";
$lang_module['path'] = "path";
$lang_module['target'] = "Mở trang liên kết";
$lang_module['who_view'] = "Quyền xem";
$lang_module['type_target1'] = "Trang hiện tại";
$lang_module['type_target2'] = "Mở tab mới";
$lang_module['type_target3'] = "Mở cửa sổ mới";
$lang_module['cat'] = "Menu này có ";
$lang_module['cat0'] = "Là mục chính";
$lang_module['cho_item'] = "Chọn loại của module";
$lang_module['cats'] = "Thuộc mục";
$lang_module['caton'] = " menu con nếu muốn xóa hãy xóa hoặc di chuyển các menu con trước";
$lang_module['error_menu_link'] = "Lỗi: Bạn chưa nhập đường link";
$lang_module['name_block'] = "Khối menu";

?>