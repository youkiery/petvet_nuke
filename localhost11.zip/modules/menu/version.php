<?php
/**
 * @Project NUKEVIET 3.0
 * @Author VINADES., JSC (contact@vinades.vn)
 * @Copyright (C) 2010 VINADES ., JSC. All rights reserved
 * @Createdate Dec 3, 2010  11:24:58 AM 
 */

$module_version = array( 
    "name" => "Module Menu", //
    "modfuncs" => "", //
    "submenu" => "", //
	"is_sysmod" => 1, //
    "virtual" => 0, //
    "version" => "3.1.00", //
    "date" => "Fri, 7 May 2010 09:47:15 GMT", //
    "author" => "VINADES (contact@vinades.vn)", //
    "note" => "",
);

?>