<?php

/**
* @Project NUKEVIET 3.0
* @Author VINADES.,JSC (contact@vinades.vn)
* @Copyright (C) 2010 VINADES.,JSC. All rights reserved
* @Language česky
* @Createdate Jul 06, 2011, 04:38:02 PM
*/

 if (!defined( 'NV_MAINFILE' )) {
 die('Stop!!!');
}

$lang_translator['author'] ="";
$lang_translator['createdate'] ="";
$lang_translator['copyright'] ="";
$lang_translator['info'] ="Language translated by http://translate.google.com";
$lang_translator['langtype'] ="lang_module";

$lang_module['faq_welcome'] = "Zde bude zobrazit odpovědi na zajímavé otazky";
$lang_module['go_top'] = "Nahoru";
$lang_module['faq_question'] = "Otázka";
$lang_module['faq_answer'] = "Odpověď";

?>