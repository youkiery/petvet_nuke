function mycarousel_initCallback(carousel)
      {
      // Disable autoscrolling if the user clicks the prev or next button.
      carousel.buttonNext.bind('click', function() {
      carousel.startAuto(0);
      });
      
      carousel.buttonPrev.bind('click', function() {
      carousel.startAuto(0);
      });
      
      // Pause autoscrolling if the user moves with the cursor over the clip.
      carousel.clip.hover(function() {
      carousel.stopAuto();
      }, function() {
      carousel.startAuto();
      });
      };
      
      jQuery(document).ready(function() {
      jQuery('#mycarousel').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel2').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel3').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel4').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel5').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel6').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel7').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel8').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      jQuery('#mycarousel9').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel10').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel11').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel12').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel13').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel14').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel15').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel16').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel17').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel18').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
jQuery('#mycarousel19').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  
	  
	  jQuery('#mycarousel30').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel31').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  
	  jQuery('#mycarousel32').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel33').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel34').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel35').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  
	  jQuery('#mycarousel60').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel61').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel62').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel63').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel64').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
	  jQuery('#mycarousel65').jcarousel({
      auto: 2,
      wrap: 'last',
      initCallback: mycarousel_initCallback
      });
      });